package assignment2;


import java.io.*;
import static java.lang.Integer.parseInt;
import java.nio.file.*;

public class generateID extends Admin{
    static File file = new File("users.txt");
    public static String generateNewID() {
        String id = "U000";
        if (file.isFile()&&file.length()>0){
            try (BufferedReader read = new BufferedReader(new FileReader ("users.txt"))){
                String line;
               while ((line = read.readLine())!= null){
                   String[] info = line.split("\t\t");
                   id = info[0];
                   System.out.println(id);
               }
                
            }catch (IOException e){
                e.printStackTrace();
            }
        }
        int idnum = Integer.parseInt(id.substring(1))+1;
        return "U"+String.format("%03d", idnum);
    }
}
