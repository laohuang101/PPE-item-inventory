package assignment2;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author hola
 */
public class Admin extends javax.swing.JFrame {

    private String ID;
    private String Name;
    private String ut;
    private String[] element = new String[4];

    public Admin() {
        initComponents();

        UserDataTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = UserDataTable.getSelectedRow();
                    if (selectedRow != -1) {
                        IdSel.setText("ID: " + UserDataTable.getValueAt(selectedRow, 0).toString());
                        NameEdit.setText(UserDataTable.getValueAt(selectedRow, 1).toString());
                        String userType = UserDataTable.getValueAt(selectedRow, 2).toString();
                        switch (userType.toUpperCase()) {
                            case "ADMIN" ->
                                adminRadio.setSelected(true);
                            case "STAFF" ->
                                staffRadio.setSelected(true);
                            default -> {
                                usertypeChoose.clearSelection();
                            }
                        }
                        PasswordTxtBox.setEnabled(false);
                        addButton.setEnabled(false);
                        editButton.setEnabled(true);
                        deleteButton.setEnabled(true);
                    } else {
                        PasswordTxtBox.setEnabled(true);
                        IdSel.setText("ID: Auto Generated");
                        NameEdit.setText("");
                        usertypeChoose.clearSelection();
                        addButton.setEnabled(true);
                        editButton.setEnabled(false);
                        deleteButton.setEnabled(false);
                    }
                }
            }
        });

        HospitalDataTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = HospitalDataTable.getSelectedRow();
                    if (selectedRow != -1) {
                        HospID.setText("ID: " + HospitalDataTable.getValueAt(selectedRow, 0).toString());
                        HospName.setText(HospitalDataTable.getValueAt(selectedRow, 1).toString());
                        Edit.setEnabled(true);
                        SaveHosp.setEnabled(false);
                    } else {
                        SaveHosp.setEnabled(true);
                        Edit.setEnabled(false);
                    }
                }
            }
        });

        SupplierDataTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    AddSupplierButton.setEnabled(false);
                    editButton1.setEnabled(true);
                    deleteButton1.setEnabled(true);
                    int selectedRow = SupplierDataTable.getSelectedRow();

                    Map<String, String> ppeDataMap = new HashMap<>();
                    try (BufferedReader br = new BufferedReader(new FileReader("ppe.txt"))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            String[] element = line.split("\t\t");
                            if (element.length >= 3) {
                                ppeDataMap.put(element[0], element[2]);
                            }
                        }
                    } catch (IOException a) {
                        a.printStackTrace();
                    }
                    HeadCoverCheckBox.setEnabled(ppeDataMap.get("HC") == null || ppeDataMap.get("HC").isEmpty());
                    FaceShieldCheckBox.setEnabled(ppeDataMap.get("FS") == null || ppeDataMap.get("FS").isEmpty());
                    MaskCheckBox.setEnabled(ppeDataMap.get("MS") == null || ppeDataMap.get("MS").isEmpty());
                    GlovesCheckBox.setEnabled(ppeDataMap.get("GL") == null || ppeDataMap.get("GL").isEmpty());
                    GownCheckBox.setEnabled(ppeDataMap.get("GW") == null || ppeDataMap.get("GW").isEmpty());
                    ShoeCheckBox.setEnabled(ppeDataMap.get("SC") == null || ppeDataMap.get("SC").isEmpty());

                    if (selectedRow != -1) {
                        String supplierID = SupplierDataTable.getValueAt(selectedRow, 0).toString();
                        SuppNameEdit.setText(SupplierDataTable.getValueAt(selectedRow, 1).toString());
                        Map<String, String> ppeSuppliersMap = new HashMap<>();
                        try (BufferedReader br = new BufferedReader(new FileReader("ppe.txt"))) {
                            String line;
                            while ((line = br.readLine()) != null) {
                                String[] element = line.split("\t\t");
                                if (element.length >= 3) {
                                    String itemCode = element[0];
                                    String supplierInPPE = element[2];
                                    if (supplierInPPE.equals(supplierID)) {
                                        ppeSuppliersMap.put(itemCode, supplierInPPE);
                                    }
                                }
                            }
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                        HeadCoverCheckBox.setSelected(ppeSuppliersMap.containsKey("HC"));
                        FaceShieldCheckBox.setSelected(ppeSuppliersMap.containsKey("FS"));
                        MaskCheckBox.setSelected(ppeSuppliersMap.containsKey("MS"));
                        GlovesCheckBox.setSelected(ppeSuppliersMap.containsKey("GL"));
                        GownCheckBox.setSelected(ppeSuppliersMap.containsKey("GW"));
                        ShoeCheckBox.setSelected(ppeSuppliersMap.containsKey("SC"));
                        if (ppeSuppliersMap.containsKey("HC")) {
                            HeadCoverCheckBox.setEnabled(true);
                        }
                        if (ppeSuppliersMap.containsKey("FS")) {
                            FaceShieldCheckBox.setEnabled(true);
                        }
                        if (ppeSuppliersMap.containsKey("MS")) {
                            MaskCheckBox.setEnabled(true);
                        }
                        if (ppeSuppliersMap.containsKey("GL")) {
                            GlovesCheckBox.setEnabled(true);
                        }
                        if (ppeSuppliersMap.containsKey("GW")) {
                            GownCheckBox.setEnabled(true);
                        }
                        if (ppeSuppliersMap.containsKey("SC")) {
                            ShoeCheckBox.setEnabled(true);
                        }
                    }
                }
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                Map<String, String> ppeDataMap = new HashMap<>();
                try (BufferedReader br = new BufferedReader(new FileReader("ppe.txt"))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        String[] element = line.split("\t\t");
                        if (element.length >= 3) {

                            ppeDataMap.put(element[0], element[2]);
                        }
                    }
                } catch (IOException a) {
                    a.printStackTrace();
                }

                HeadCoverCheckBox.setEnabled(ppeDataMap.get("HC") == null || ppeDataMap.get("HC").isEmpty());
                FaceShieldCheckBox.setEnabled(ppeDataMap.get("FS") == null || ppeDataMap.get("FS").isEmpty());
                MaskCheckBox.setEnabled(ppeDataMap.get("MS") == null || ppeDataMap.get("MS").isEmpty());
                GlovesCheckBox.setEnabled(ppeDataMap.get("GL") == null || ppeDataMap.get("GL").isEmpty());
                GownCheckBox.setEnabled(ppeDataMap.get("GW") == null || ppeDataMap.get("GW").isEmpty());
                ShoeCheckBox.setEnabled(ppeDataMap.get("SC") == null || ppeDataMap.get("SC").isEmpty());
            }
        });

    }

    public void getInfo(String ID, String Name, String userType) {
        this.ID = ID;
        this.Name = Name;
        this.ut = userType;
        NameLabel.setText(Name);
        IdLabel.setText(ID);
        Role.setText(ut);

        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
        if (UserDataTable.getSelectedRow() == -1) {
            addButton.setEnabled(true);
            addButton.setVisible(true);

        } else {
            addButton.setEnabled(false);
            addButton.setVisible(false);
        }
    }

    public void refresh() {
        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
        String[] header = {"User Id", "Name", "User Type", "Password"};
        model.setColumnIdentifiers(header);
        model.setRowCount(0);
        try {
            BufferedReader BF = new BufferedReader(new FileReader("users.txt"));
            String line;
            while ((line = BF.readLine()) != null) {
                String[] element = line.split("\t\t");

                if (element.length >= 4) {
                    String[] uinfo = {element[0], element[1], element[2], element[3]};
                    model.addRow(uinfo);
                }
            }
            TableColumn column = UserDataTable.getColumnModel().getColumn(3);
            UserDataTable.removeColumn(column);
            BF.close();
        } catch (Exception e) {
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        usertypeChoose = new javax.swing.ButtonGroup();
        jPanel4 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        SearchBar3 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        UserDataTable3 = new javax.swing.JTable();
        UTsort3 = new javax.swing.JComboBox<>();
        RefreshButton3 = new javax.swing.JButton();
        Sort3 = new javax.swing.JComboBox<>();
        jLabel19 = new javax.swing.JLabel();
        editButton3 = new javax.swing.JButton();
        PasswordTxtBox3 = new javax.swing.JTextField();
        deleteButton3 = new javax.swing.JButton();
        addButton3 = new javax.swing.JButton();
        IdSel3 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        NameEdit3 = new javax.swing.JTextField();
        NameLabel = new javax.swing.JLabel();
        IdLabel = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        Logout = new javax.swing.JButton();
        Hospital = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        SearchBar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        UserDataTable = new javax.swing.JTable();
        UTsort = new javax.swing.JComboBox<>();
        RefreshButton = new javax.swing.JButton();
        Sort = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        editButton = new javax.swing.JButton();
        PasswordTxtBox = new javax.swing.JTextField();
        deleteButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        IdSel = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        NameEdit = new javax.swing.JTextField();
        adminRadio = new javax.swing.JRadioButton();
        staffRadio = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        SearchBar1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        SupplierDataTable = new javax.swing.JTable();
        SupRefreshButton = new javax.swing.JButton();
        Sort1 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        IdSel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        SuppNameEdit = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        AddSupplierButton = new javax.swing.JButton();
        editButton1 = new javax.swing.JButton();
        deleteButton1 = new javax.swing.JButton();
        HeadCoverCheckBox = new javax.swing.JCheckBox();
        FaceShieldCheckBox = new javax.swing.JCheckBox();
        GlovesCheckBox = new javax.swing.JCheckBox();
        MaskCheckBox = new javax.swing.JCheckBox();
        ShoeCheckBox = new javax.swing.JCheckBox();
        GownCheckBox = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        SearchBar2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Sort4 = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        HospitalDataTable = new javax.swing.JTable();
        HospID = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        HospName = new javax.swing.JTextField();
        SaveHosp = new javax.swing.JButton();
        SupRefreshButton1 = new javax.swing.JButton();
        Edit = new javax.swing.JButton();
        Role = new javax.swing.JLabel();

        jLabel18.setText("Search");

        SearchBar3.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        SearchBar3.setForeground(new java.awt.Color(102, 102, 102));
        SearchBar3.setText("Search Here");
        SearchBar3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                SearchBar3FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                SearchBar3FocusLost(evt);
            }
        });
        SearchBar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBar3ActionPerformed(evt);
            }
        });
        SearchBar3.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchBar3PropertyChange(evt);
            }
        });
        SearchBar3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SearchBar3KeyPressed(evt);
            }
        });

        UserDataTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        UserDataTable3.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                UserDataTable3PropertyChange(evt);
            }
        });
        jScrollPane4.setViewportView(UserDataTable3);

        UTsort3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "ADMIN", "STAFF"}));
        UTsort3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UTsort3ActionPerformed(evt);
            }
        });

        RefreshButton3.setText("Refresh");
        RefreshButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButton3ActionPerformed(evt);
            }
        });

        Sort3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A-Z", "Z-A"}));
        Sort3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sort3ActionPerformed(evt);
            }
        });

        jLabel19.setText("Sort");

        editButton3.setText("Edit");
        editButton3.setEnabled(false);
        editButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButton3ActionPerformed(evt);
            }
        });

        deleteButton3.setText("Delete");
        deleteButton3.setEnabled(false);
        deleteButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButton3ActionPerformed(evt);
            }
        });

        addButton3.setText("Add User");
        addButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButton3ActionPerformed(evt);
            }
        });

        IdSel3.setText("ID:  Auto Generated");

        jLabel20.setText("Name");

        jLabel22.setText("Password");

        NameEdit3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameEdit3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SearchBar3, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Sort3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(UTsort3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(RefreshButton3))
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(26, 26, 26)
                                    .addComponent(PasswordTxtBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(36, 36, 36)
                                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(NameEdit3, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(editButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(addButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(deleteButton3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(21, 21, 21)))
                            .addComponent(IdSel3, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(SearchBar3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Sort3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19)
                            .addComponent(UTsort3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(RefreshButton3))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel20)
                                .addComponent(NameEdit3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(IdSel3)
                                .addGap(51, 51, 51)))
                        .addGap(54, 54, 54)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PasswordTxtBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22))
                        .addGap(18, 18, 18)
                        .addComponent(addButton3)
                        .addGap(18, 18, 18)
                        .addComponent(editButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(deleteButton3)))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        NameLabel.setText("Name");
        NameLabel.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                NameLabelPropertyChange(evt);
            }
        });

        IdLabel.setText("ID");

        Logout.setText("Logout");
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });

        jLabel3.setText("Search");

        SearchBar.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        SearchBar.setForeground(new java.awt.Color(102, 102, 102));
        SearchBar.setText("Search Here");
        SearchBar.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                SearchBarFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                SearchBarFocusLost(evt);
            }
        });
        SearchBar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBarActionPerformed(evt);
            }
        });
        SearchBar.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchBarPropertyChange(evt);
            }
        });
        SearchBar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SearchBarKeyPressed(evt);
            }
        });

        UserDataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        UserDataTable.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                UserDataTablePropertyChange(evt);
            }
        });
        jScrollPane1.setViewportView(UserDataTable);

        UTsort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL", "ADMIN", "STAFF"}));
        UTsort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UTsortActionPerformed(evt);
            }
        });

        RefreshButton.setText("Refresh");
        RefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RefreshButtonActionPerformed(evt);
            }
        });

        Sort.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A-Z", "Z-A"}));
        Sort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SortActionPerformed(evt);
            }
        });

        jLabel4.setText("Sort");

        editButton.setText("Edit");
        editButton.setEnabled(false);
        editButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButtonActionPerformed(evt);
            }
        });

        deleteButton.setText("Delete");
        deleteButton.setEnabled(false);
        deleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButtonActionPerformed(evt);
            }
        });

        addButton.setText("Add User");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });

        IdSel.setText("ID:  Auto Generated");

        jLabel6.setText("Name");

        jLabel7.setText("User Type");

        jLabel8.setText("Password");

        usertypeChoose.add(adminRadio);
        adminRadio.setText("Admin");
        adminRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminRadioActionPerformed(evt);
            }
        });

        usertypeChoose.add(staffRadio);
        staffRadio.setText("Staff");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(280, 280, 280))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Sort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(UTsort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(RefreshButton))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(55, 55, 55)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NameEdit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(adminRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(staffRadio, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(PasswordTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(editButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(addButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(deleteButton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(76, 76, 76))
                            .addComponent(IdSel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(25, 25, 25))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {adminRadio, staffRadio});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(SearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Sort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(UTsort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(RefreshButton))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(NameEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(IdSel)
                                .addGap(51, 51, 51)))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(adminRadio))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(staffRadio)
                        .addGap(57, 57, 57)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(PasswordTxtBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8))
                        .addGap(18, 18, 18)
                        .addComponent(addButton)
                        .addGap(18, 18, 18)
                        .addComponent(editButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(deleteButton)))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        Hospital.addTab("User Data", jPanel1);

        jLabel5.setText("Search");

        SearchBar1.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        SearchBar1.setForeground(new java.awt.Color(102, 102, 102));
        SearchBar1.setText("Search Here");
        SearchBar1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                SearchBar1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                SearchBar1FocusLost(evt);
            }
        });
        SearchBar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBar1ActionPerformed(evt);
            }
        });
        SearchBar1.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchBar1PropertyChange(evt);
            }
        });
        SearchBar1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SearchBar1KeyPressed(evt);
            }
        });

        SupplierDataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        SupplierDataTable.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SupplierDataTablePropertyChange(evt);
            }
        });
        jScrollPane2.setViewportView(SupplierDataTable);

        SupRefreshButton.setText("Refresh");
        SupRefreshButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupRefreshButtonActionPerformed(evt);
            }
        });

        Sort1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A-Z", "Z-A"}));
        Sort1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sort1ActionPerformed(evt);
            }
        });

        jLabel9.setText("Sort");

        IdSel1.setText("ID:  Auto Generated");

        jLabel10.setText("Name");

        jLabel11.setText("Item Supplied");

        AddSupplierButton.setText("Add Supplier");
        AddSupplierButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddSupplierButtonActionPerformed(evt);
            }
        });

        editButton1.setText("Edit");
        editButton1.setEnabled(false);
        editButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editButton1ActionPerformed(evt);
            }
        });

        deleteButton1.setText("Delete");
        deleteButton1.setEnabled(false);
        deleteButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteButton1ActionPerformed(evt);
            }
        });

        HeadCoverCheckBox.setText("Head Cover");
        HeadCoverCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HeadCoverCheckBoxActionPerformed(evt);
            }
        });

        FaceShieldCheckBox.setText("Face Shield");

        GlovesCheckBox.setText("Gloves");

        MaskCheckBox.setText("Mask");

        ShoeCheckBox.setText("Shoe Covers");

        GownCheckBox.setText("Gown");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SearchBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Sort1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SupRefreshButton))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(IdSel1, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addComponent(editButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(39, 39, 39)
                                            .addComponent(deleteButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel3Layout.createSequentialGroup()
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(MaskCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                    .addComponent(SuppNameEdit)
                                                    .addComponent(HeadCoverCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(FaceShieldCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE))
                                                .addComponent(GlovesCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(GownCheckBox, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(ShoeCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addContainerGap(31, Short.MAX_VALUE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(111, 111, 111)
                                .addComponent(AddSupplierButton)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {FaceShieldCheckBox, GlovesCheckBox, GownCheckBox, HeadCoverCheckBox, MaskCheckBox, ShoeCheckBox});

        jPanel3Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {AddSupplierButton, deleteButton1, editButton1});

        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(SearchBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Sort1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(SupRefreshButton)
                            .addComponent(IdSel1))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(32, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(SuppNameEdit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(HeadCoverCheckBox))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(FaceShieldCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(MaskCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GlovesCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(GownCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ShoeCheckBox)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(AddSupplierButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(editButton1)
                            .addComponent(deleteButton1))
                        .addGap(45, 45, 45))))
        );

        jPanel3Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {FaceShieldCheckBox, GlovesCheckBox, GownCheckBox, HeadCoverCheckBox, MaskCheckBox, ShoeCheckBox});

        Hospital.addTab("Supplier Details", jPanel3);

        jLabel12.setText("Search");

        SearchBar2.setFont(new java.awt.Font("Times New Roman", 2, 12)); // NOI18N
        SearchBar2.setForeground(new java.awt.Color(102, 102, 102));
        SearchBar2.setText("Search Here");
        SearchBar2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                SearchBar2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                SearchBar2FocusLost(evt);
            }
        });
        SearchBar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchBar2ActionPerformed(evt);
            }
        });
        SearchBar2.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                SearchBar2PropertyChange(evt);
            }
        });
        SearchBar2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SearchBar2KeyPressed(evt);
            }
        });

        jLabel1.setText("Sort: ");

        Sort4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A-Z","Z-A"}));
        Sort4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Sort4ActionPerformed(evt);
            }
        });

        HospitalDataTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        HospitalDataTable.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                HospitalDataTablePropertyChange(evt);
            }
        });
        jScrollPane3.setViewportView(HospitalDataTable);

        HospID.setText("ID: Auto Generated");

        jLabel13.setText("Name: ");

        SaveHosp.setText("Save");
        SaveHosp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveHospActionPerformed(evt);
            }
        });

        SupRefreshButton1.setText("Refresh");
        SupRefreshButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SupRefreshButton1ActionPerformed(evt);
            }
        });

        Edit.setText("Edit");
        Edit.setEnabled(false);
        Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(SearchBar2, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Sort4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SupRefreshButton1))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 458, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(HospName, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(HospID, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(61, 61, 61)
                                .addComponent(SaveHosp)
                                .addGap(18, 18, 18)
                                .addComponent(Edit)))))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SearchBar2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(27, 27, 27)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Sort4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SupRefreshButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(33, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(HospID)
                        .addGap(43, 43, 43)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(HospName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(SaveHosp)
                            .addComponent(Edit))
                        .addGap(72, 72, 72))))
        );

        Hospital.addTab("Hospital Details", jPanel2);

        Role.setText("Role:");
        Role.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                RolePropertyChange(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Hospital, javax.swing.GroupLayout.PREFERRED_SIZE, 771, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(IdLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(124, 124, 124)
                                        .addComponent(Role, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(502, 502, 502)
                                .addComponent(Logout)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(NameLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(IdLabel)
                            .addComponent(Role)))
                    .addComponent(Logout, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Hospital, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void NameLabelPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_NameLabelPropertyChange

    }//GEN-LAST:event_NameLabelPropertyChange

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        new Login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_LogoutActionPerformed

    private void adminRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminRadioActionPerformed

    }//GEN-LAST:event_adminRadioActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();

        if (UserDataTable.getSelectedRow() != -1) {
            JOptionPane.showMessageDialog(this, "Please do not select data from the table");
        } else {
            String name = NameEdit.getText().trim();
            String password = PasswordTxtBox.getText().trim();

            if (name.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name and Password cannot be empty");
                return;
            }

            element[0] = generateID.generateNewID();
            element[1] = name;
            if ((usertypeChoose.getSelection() != null)) {
                adminRadio.setActionCommand("Admin");
                staffRadio.setActionCommand("Staff");

                String selectedValue = usertypeChoose.getSelection().getActionCommand();
                element[2] = selectedValue;
                element[3] = password;

                try {
                    BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt", true));
                    bw.write(String.join("\t\t", element));
                    bw.newLine();
                    bw.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error saving data", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a User Type");
            }

            NameEdit.setText("");
            usertypeChoose.clearSelection();
            PasswordTxtBox.setText("");
            this.refresh();
        }
    }//GEN-LAST:event_addButtonActionPerformed

    private void deleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButtonActionPerformed
        int row = UserDataTable.getSelectedRow();
        if (row != -1) {
            DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
            model.removeRow(row);
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.write(model.getValueAt(i, j).toString());
                        if (j < model.getColumnCount() - 1) {
                            writer.write("\t\t");
                        }
                    }
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(this, "User has been removed sucessfully");
            } catch (IOException e) {
            }
        }
    }//GEN-LAST:event_deleteButtonActionPerformed

    private void editButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButtonActionPerformed
        int row = UserDataTable.getSelectedRow();
        if (row != -1) {
            UserDataTable.setValueAt(NameEdit.getText(), row, 1);
            adminRadio.setActionCommand("Admin");
            staffRadio.setActionCommand("Staff");
            UserDataTable.setValueAt(usertypeChoose.getSelection().getActionCommand(), row, 2);
        }
        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString());
                    if (j < model.getColumnCount() - 1) {
                        writer.write("\t\t");
                    }
                }
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "Data saved to successfully");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving data", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_editButtonActionPerformed

    private void SortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SortActionPerformed
        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
        UserDataTable.setRowSorter(sorter);
        String selectedSortOrder = (String) Sort.getSelectedItem();
        if ("A-Z".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.ASCENDING)));
        } else if ("Z-A".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.DESCENDING)));
        }
    }//GEN-LAST:event_SortActionPerformed

    private void RefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButtonActionPerformed
        this.refresh();
    }//GEN-LAST:event_RefreshButtonActionPerformed

    private void UTsortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UTsortActionPerformed
        DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
        String selectedOption = (String) UTsort.getSelectedItem();
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
        UserDataTable.setRowSorter(sorter);

        if (selectedOption.equals("ALL")) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(new RowFilter<TableModel, Integer>() {
                public boolean include(RowFilter.Entry<? extends TableModel, ? extends Integer> entry) {
                    return entry.getStringValue(2).toUpperCase().equals(selectedOption);
                }

            });
        }
    }//GEN-LAST:event_UTsortActionPerformed

    private void UserDataTablePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_UserDataTablePropertyChange
        this.refresh();
    }//GEN-LAST:event_UserDataTablePropertyChange

    private void SearchBarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchBarKeyPressed
        int key = evt.getKeyCode();
        if (key == 10) {
            DefaultTableModel model = (DefaultTableModel) UserDataTable.getModel();
            try {
                BufferedReader br = new BufferedReader(new FileReader("users.txt"));
                String line;
                model.setRowCount(0);
                while ((line = br.readLine()) != null) {
                    String[] element = line.split("\t\t");
                    for (String UserData : element) {
                        if (UserData.toUpperCase().contains(SearchBar.getText().toUpperCase())) {
                            model.addRow(element);
                            break;
                        }
                    }

                }
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_SearchBarKeyPressed

    private void SearchBarPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchBarPropertyChange

    }//GEN-LAST:event_SearchBarPropertyChange

    private void SearchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBarActionPerformed

    }//GEN-LAST:event_SearchBarActionPerformed

    private void SearchBarFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBarFocusLost
        if (SearchBar.getText().equals("")) {
            SearchBar.setText("Search Here");
            SearchBar.setForeground(Color.GRAY);
            SearchBar.setFont(new Font("Times New Roman", Font.ITALIC, 12));
        }
    }//GEN-LAST:event_SearchBarFocusLost

    private void SearchBarFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBarFocusGained
        if (SearchBar.getText().equals("") || SearchBar.getText().equals("Search Here")) {
            SearchBar.setText("");
            SearchBar.setForeground(Color.BLACK);
            SearchBar.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        }
    }//GEN-LAST:event_SearchBarFocusGained

    private void SearchBar1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar1FocusGained
        if (SearchBar1.getText().equals("") || SearchBar1.getText().equals("Search Here")) {
            SearchBar1.setText("");
            SearchBar1.setForeground(Color.BLACK);
            SearchBar1.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        }
    }//GEN-LAST:event_SearchBar1FocusGained

    private void SearchBar1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar1FocusLost
        if (SearchBar1.getText().equals("")) {
            SearchBar1.setText("Search Here");
            SearchBar1.setForeground(Color.GRAY);
            SearchBar1.setFont(new Font("Times New Roman", Font.ITALIC, 12));
        }
    }//GEN-LAST:event_SearchBar1FocusLost

    private void SearchBar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar1ActionPerformed

    private void SearchBar1PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchBar1PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar1PropertyChange

    private void SearchBar1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchBar1KeyPressed
        int key = evt.getKeyCode();
        if (key == 10) {
            DefaultTableModel model = (DefaultTableModel) SupplierDataTable.getModel();
            try {
                BufferedReader br = new BufferedReader(new FileReader("suppliers.txt"));
                String line;
                model.setRowCount(0);
                while ((line = br.readLine()) != null) {
                    String[] element = line.split("\t\t");
                    for (String UserData : element) {
                        if (UserData.toUpperCase().contains(SearchBar1.getText().toUpperCase())) {
                            model.addRow(element);
                            break;
                        }
                    }

                }
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_SearchBar1KeyPressed

    private void SupplierDataTablePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SupplierDataTablePropertyChange
        DefaultTableModel model = (DefaultTableModel) SupplierDataTable.getModel();
        String[] heading = {"Supplier ID", "Supplier Name"};
        model.setColumnIdentifiers(heading);
        this.supRefresh();
    }//GEN-LAST:event_SupplierDataTablePropertyChange

    private void SupRefreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupRefreshButtonActionPerformed
        this.supRefresh();
    }//GEN-LAST:event_SupRefreshButtonActionPerformed

    private void Sort1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sort1ActionPerformed
        DefaultTableModel model = (DefaultTableModel) SupplierDataTable.getModel();
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
        SupplierDataTable.setRowSorter(sorter);
        String selectedSortOrder = (String) Sort1.getSelectedItem();
        if ("A-Z".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.ASCENDING)));
        } else if ("Z-A".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.DESCENDING)));
        }
    }//GEN-LAST:event_Sort1ActionPerformed

    private void loadPPEData() {
        try (BufferedReader br = new BufferedReader(new FileReader("ppe.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] element = line.split("\t\t");
                String itemCode = element[0];
                String supplierID = element[2];

                switch (itemCode) {
                    case "HC":
                        if (!supplierID.equals("-")) {
                            HeadCoverCheckBox.setEnabled(false);
                        } else {
                            HeadCoverCheckBox.setEnabled(true);
                        }
                        break;
                    case "FS":
                        if (!supplierID.equals("-")) {
                            FaceShieldCheckBox.setEnabled(false);
                        } else {
                            FaceShieldCheckBox.setEnabled(true);
                        }
                        break;
                    case "MS":
                        if (!supplierID.equals("-")) {
                            MaskCheckBox.setEnabled(false);
                        } else {
                            MaskCheckBox.setEnabled(true);
                        }
                        break;
                    case "GL":
                        if (!supplierID.equals("-")) {
                            GlovesCheckBox.setEnabled(false);
                        } else {
                            GlovesCheckBox.setEnabled(true);
                        }
                        break;
                    case "GW":
                        if (!supplierID.equals("-")) {
                            GownCheckBox.setEnabled(false);
                        } else {
                            GownCheckBox.setEnabled(true);
                        }
                        break;
                    case "SC":
                        if (!supplierID.equals("-")) {
                            ShoeCheckBox.setEnabled(false);
                        } else {
                            ShoeCheckBox.setEnabled(true);
                        }
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private void editButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButton1ActionPerformed
        int row = SupplierDataTable.getSelectedRow();
        if (row != -1) {
            String supplierID = SupplierDataTable.getValueAt(row, 0).toString();
            String newSupplierName = SuppNameEdit.getText().trim();
            SupplierDataTable.setValueAt(newSupplierName, row, 1);

            boolean hcSelected = HeadCoverCheckBox.isSelected();
            boolean fsSelected = FaceShieldCheckBox.isSelected();
            boolean msSelected = MaskCheckBox.isSelected();
            boolean glSelected = GlovesCheckBox.isSelected();
            boolean gwSelected = GownCheckBox.isSelected();
            boolean scSelected = ShoeCheckBox.isSelected();
            List<String[]> supplierData = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader("suppliers.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] element = line.split("\t\t");
                    if (element[0].equals(supplierID)) {
                        element[1] = newSupplierName;
                    }
                    supplierData.add(element);
                }

                try (BufferedWriter bw = new BufferedWriter(new FileWriter("suppliers.txt"))) {
                    for (String[] element : supplierData) {
                        bw.write(element[0] + "\t\t" + element[1]);
                        bw.newLine();
                    }
                    JOptionPane.showMessageDialog(this, "Supplier name updated successfully.");
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating suppliers.txt", "Error", JOptionPane.ERROR_MESSAGE);
            }
            List<String[]> ppeData = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader("ppe.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] element = line.split("\t\t");

                    if (element.length > 2) {
                        if (element[2].equals(supplierID)) {
                            element[2] = "";
                        }
                        if ((hcSelected && "HC".equals(element[0]))
                                || (fsSelected && "FS".equals(element[0]))
                                || (msSelected && "MS".equals(element[0]))
                                || (glSelected && "GL".equals(element[0]))
                                || (gwSelected && "GW".equals(element[0]))
                                || (scSelected && "SC".equals(element[0]))) {
                            element[2] = supplierID;
                        }
                    }
                    ppeData.add(element);
                }
                try (BufferedWriter bw = new BufferedWriter(new FileWriter("ppe.txt"))) {
                    for (String[] element : ppeData) {
                        bw.write(String.join("\t\t", element));
                        bw.newLine();
                    }
                    JOptionPane.showMessageDialog(this, "PPE data updated successfully.");
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error updating ppe.txt", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if (hcSelected) {
                HeadCoverCheckBox.setSelected(false);
                HeadCoverCheckBox.setEnabled(false);
            }
            if (fsSelected) {
                FaceShieldCheckBox.setSelected(false);
                FaceShieldCheckBox.setEnabled(false);
            }
            if (msSelected) {
                MaskCheckBox.setSelected(false);
                MaskCheckBox.setEnabled(false);
            }
            if (glSelected) {
                GlovesCheckBox.setSelected(false);
                GlovesCheckBox.setEnabled(false);
            }
            if (gwSelected) {
                GownCheckBox.setSelected(false);
                GownCheckBox.setEnabled(false);
            }
            if (scSelected) {
                ShoeCheckBox.setSelected(false);
                ShoeCheckBox.setEnabled(false);
            }

            this.supRefresh();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a supplier and at least one item to supply.");
        }

    }//GEN-LAST:event_editButton1ActionPerformed

    private void deleteButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButton1ActionPerformed
        int row = SupplierDataTable.getSelectedRow();
        if (row != -1) {
            DefaultTableModel model = (DefaultTableModel) SupplierDataTable.getModel();
            String deletedTransactionID = model.getValueAt(row, 0).toString();
            model.removeRow(row);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("suppliers.txt"))) {
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        writer.write(model.getValueAt(i, j).toString());
                        if (j < model.getColumnCount() - 1) {
                            writer.write("\t\t");
                        }
                    }
                    writer.newLine();
                }
                JOptionPane.showMessageDialog(this, "Supplier has been removed successfully");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error saving data", "Error", JOptionPane.ERROR_MESSAGE);
            }

            try {
                List<String> lines = Files.readAllLines(Paths.get("ppe.txt"));
                for (int i = 0; i < lines.size(); i++) {
                    String[] elements = lines.get(i).split("\t\t");
                    if (elements.length >= 2 && elements[2].equals(deletedTransactionID)) {
                        elements[2] = "";
                        lines.set(i, String.join("\t\t", elements));
                    }
                }
                Files.write(Paths.get("ppe.txt"), lines);
                JOptionPane.showMessageDialog(this, "ppe.txt has been updated successfully");
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error updating ppe.txt", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }
        this.supRefresh();
    }//GEN-LAST:event_deleteButton1ActionPerformed

    public void supRefresh() {
        DefaultTableModel model = (DefaultTableModel) SupplierDataTable.getModel();
        String[] header = {"Supplier ID", "Supplier Name"};
        model.setColumnIdentifiers(header);
        model.setRowCount(0);
        try {
            BufferedReader BR = new BufferedReader(new FileReader("suppliers.txt"));
            String line;
            while ((line = BR.readLine()) != null) {
                String[] element = line.split("\t\t");

                if (element.length > 1) {
                    String[] sinfo = {element[0], element[1]};
                    model.addRow(sinfo);
                }
            }
            BR.close();
        } catch (Exception e) {
        }
        IdSel1.setText("ID: Auto Generated");
        SuppNameEdit.setText("");
        HeadCoverCheckBox.setSelected(false);
        FaceShieldCheckBox.setSelected(false);
        MaskCheckBox.setSelected(false);
        GlovesCheckBox.setSelected(false);
        GownCheckBox.setSelected(false);
        ShoeCheckBox.setSelected(false);
        AddSupplierButton.setEnabled(true);
        editButton1.setEnabled(false);
        deleteButton1.setEnabled(false);
    }

    private void AddSupplierButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddSupplierButtonActionPerformed
        String supName = SuppNameEdit.getText();
        String HCSelect = HeadCoverCheckBox.isSelected() ? "HC" : "-";
        String FSSelect = FaceShieldCheckBox.isSelected() ? "FS" : "-";
        String MSSelect = MaskCheckBox.isSelected() ? "MS" : "-";
        String GLSelect = GlovesCheckBox.isSelected() ? "GL" : "-";
        String GWSelect = GownCheckBox.isSelected() ? "GW" : "-";
        String SCSelect = ShoeCheckBox.isSelected() ? "SC" : "-";

        if (!HCSelect.equals("-") || !FSSelect.equals("-") || !MSSelect.equals("-") || !GLSelect.equals("-") || !GWSelect.equals("-") || !SCSelect.equals("-")) {
            String id = "S000";
            File file = new File("suppliers.txt");
            if (file.isFile() && file.length() > 0) {
                try (BufferedReader read = new BufferedReader(new FileReader("suppliers.txt"))) {
                    String line;
                    while ((line = read.readLine()) != null) {
                        String[] info = line.split("\t\t");
                        id = info[0];
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int idnum = Integer.parseInt(id.substring(1)) + 1;
            String supID = "S" + String.format("%03d", idnum);

            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("suppliers.txt", true));
                bw.write(supID + "\t\t" + supName);
                bw.newLine();
                bw.close();
                List<String> lines = Files.readAllLines(Paths.get("ppe.txt"));
                for (int i = 0; i < lines.size(); i++) {
                    String[] elements = lines.get(i).split("\t\t");
                    if ((HCSelect.equals("HC") && "HC".equals(elements[0]))
                            || (FSSelect.equals("FS") && "FS".equals(elements[0]))
                            || (MSSelect.equals("MS") && "MS".equals(elements[0]))
                            || (GLSelect.equals("GL") && "GL".equals(elements[0]))
                            || (GWSelect.equals("GW") && "GW".equals(elements[0]))
                            || (SCSelect.equals("SC") && "SC".equals(elements[0]))) {
                        elements[2] = supID;
                        lines.set(i, String.join("\t\t", elements));
                    }
                }
                Files.write(Paths.get("ppe.txt"), lines);
                if (!HCSelect.equals("-")) {
                    HeadCoverCheckBox.setSelected(false);
                    HeadCoverCheckBox.setEnabled(false);
                }
                if (!FSSelect.equals("-")) {
                    FaceShieldCheckBox.setSelected(false);
                    FaceShieldCheckBox.setEnabled(false);
                }
                if (!MSSelect.equals("-")) {
                    MaskCheckBox.setSelected(false);
                    MaskCheckBox.setEnabled(false);
                }
                if (!GLSelect.equals("-")) {
                    GlovesCheckBox.setSelected(false);
                    GlovesCheckBox.setEnabled(false);
                }
                if (!GWSelect.equals("-")) {
                    GownCheckBox.setSelected(false);
                    GownCheckBox.setEnabled(false);
                }
                if (!SCSelect.equals("-")) {
                    ShoeCheckBox.setSelected(false);
                    ShoeCheckBox.setEnabled(false);
                }

                JOptionPane.showMessageDialog(this, "Data Updated Successfully");
                this.supRefresh();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error saving data", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select at least one item supply");
        }

    }//GEN-LAST:event_AddSupplierButtonActionPerformed


    private void HeadCoverCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HeadCoverCheckBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_HeadCoverCheckBoxActionPerformed

    private void addButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addButton3ActionPerformed

    private void deleteButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_deleteButton3ActionPerformed

    private void editButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_editButton3ActionPerformed

    private void Sort3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sort3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Sort3ActionPerformed

    private void UTsort3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UTsort3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UTsort3ActionPerformed

    private void SearchBar3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchBar3KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar3KeyPressed

    private void SearchBar3PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchBar3PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar3PropertyChange

    private void SearchBar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBar3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar3ActionPerformed

    private void SearchBar3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar3FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar3FocusLost

    private void SearchBar3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar3FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar3FocusGained

    private void NameEdit3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameEdit3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NameEdit3ActionPerformed

    private void UserDataTable3PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_UserDataTable3PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_UserDataTable3PropertyChange

    private void RefreshButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RefreshButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_RefreshButton3ActionPerformed

    private void SearchBar2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar2FocusGained
        if (SearchBar2.getText().equals("") || SearchBar2.getText().equals("Search Here")) {
            SearchBar2.setText("");
            SearchBar2.setForeground(Color.BLACK);
            SearchBar2.setFont(new Font("Times New Roman", Font.PLAIN, 12));
        }
    }//GEN-LAST:event_SearchBar2FocusGained

    private void SearchBar2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_SearchBar2FocusLost
        if (SearchBar2.getText().equals("")) {
            SearchBar2.setText("Search Here");
            SearchBar2.setForeground(Color.GRAY);
            SearchBar2.setFont(new Font("Times New Roman", Font.ITALIC, 12));
        }
    }//GEN-LAST:event_SearchBar2FocusLost

    private void SearchBar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchBar2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar2ActionPerformed

    private void SearchBar2PropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_SearchBar2PropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchBar2PropertyChange

    private void SearchBar2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchBar2KeyPressed
        int key = evt.getKeyCode();
        if (key == 10) {
            DefaultTableModel model = (DefaultTableModel) HospitalDataTable.getModel();
            try {
                BufferedReader br = new BufferedReader(new FileReader("hospitals.txt"));
                String line;
                model.setRowCount(0);
                while ((line = br.readLine()) != null) {
                    String[] element = line.split("\t\t");
                    for (String UserData : element) {
                        if (UserData.toUpperCase().contains(SearchBar2.getText().toUpperCase())) {
                            model.addRow(element);
                            break;
                        }
                    }

                }
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_SearchBar2KeyPressed

    private void SaveHospActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveHospActionPerformed
        DefaultTableModel model = (DefaultTableModel) HospitalDataTable.getModel();

        if (HospitalDataTable.getSelectedRow() != -1) {
            JOptionPane.showMessageDialog(this, "Please do not select data from the table");
        } else {
            String id = "H000";
            File file = new File("hospitals.txt");
            if (file.isFile() && file.length() > 0) {
                try (BufferedReader read = new BufferedReader(new FileReader("hospitals.txt"))) {
                    String line;
                    while ((line = read.readLine()) != null) {
                        String[] info = line.split("\t\t");
                        id = info[0];
                        System.out.println(id);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int idnum = Integer.parseInt(id.substring(1)) + 1;

            String hospID = "H" + String.format("%03d", idnum);
            String hospName = HospName.getText();

            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("hospitals.txt", true));
                bw.write(hospID + "\t\t" + hospName);
                bw.newLine();
                bw.close();
            } catch (IOException ex) {
            }
            HospID.setText("ID: Auto Generated");
            HospName.setText("");
            this.hospitalRefresh();

        }
    }//GEN-LAST:event_SaveHospActionPerformed

    private void HospitalDataTablePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_HospitalDataTablePropertyChange
        this.hospitalRefresh();
    }//GEN-LAST:event_HospitalDataTablePropertyChange

    public void hospitalRefresh() {
        DefaultTableModel model = (DefaultTableModel) HospitalDataTable.getModel();
        String[] header = {"Hospital Id", "Name"};
        model.setColumnIdentifiers(header);
        model.setRowCount(0);
        try {
            BufferedReader BF = new BufferedReader(new FileReader("hospitals.txt"));
            String line;
            while ((line = BF.readLine()) != null) {
                String[] element = line.split("\t\t");

                if (element.length >= 2) {
                    String[] uinfo = {element[0], element[1]};
                    model.addRow(uinfo);
                }
            }

            BF.close();
        } catch (Exception e) {
        }
    }

    private void SupRefreshButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SupRefreshButton1ActionPerformed
        this.hospitalRefresh();
    }//GEN-LAST:event_SupRefreshButton1ActionPerformed

    private void Sort4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Sort4ActionPerformed
        DefaultTableModel model = (DefaultTableModel) HospitalDataTable.getModel();
        TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
        HospitalDataTable.setRowSorter(sorter);
        String selectedSortOrder = (String) Sort4.getSelectedItem();
        if ("A-Z".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.ASCENDING)));
        } else if ("Z-A".equals(selectedSortOrder)) {
            sorter.setSortKeys(List.of(new RowSorter.SortKey(1, SortOrder.DESCENDING)));
        }
    }//GEN-LAST:event_Sort4ActionPerformed

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
        int row = HospitalDataTable.getSelectedRow();
        if (row != -1) {
            HospitalDataTable.setValueAt(HospName.getText(), row, 1);

        }
        DefaultTableModel model = (DefaultTableModel) HospitalDataTable.getModel();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("hospitals.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    writer.write(model.getValueAt(i, j).toString());
                    if (j < model.getColumnCount() - 1) {
                        writer.write("\t\t");
                    }
                }
                writer.newLine();
            }
            JOptionPane.showMessageDialog(this, "Data saved to successfully");
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving data");
        }
        HospID.setText("ID: Auto Generate");
        HospName.setText("");
        this.hospitalRefresh();
    }//GEN-LAST:event_EditActionPerformed

    private void RolePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_RolePropertyChange
        // TODO add your handling code here:
    }//GEN-LAST:event_RolePropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        ;
    }
    );
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddSupplierButton;
    private javax.swing.JButton Edit;
    private javax.swing.JCheckBox FaceShieldCheckBox;
    private javax.swing.JCheckBox GlovesCheckBox;
    private javax.swing.JCheckBox GownCheckBox;
    private javax.swing.JCheckBox HeadCoverCheckBox;
    private javax.swing.JLabel HospID;
    private javax.swing.JTextField HospName;
    private javax.swing.JTabbedPane Hospital;
    private javax.swing.JTable HospitalDataTable;
    private javax.swing.JLabel IdLabel;
    private javax.swing.JLabel IdSel;
    private javax.swing.JLabel IdSel1;
    private javax.swing.JLabel IdSel3;
    private javax.swing.JButton Logout;
    private javax.swing.JCheckBox MaskCheckBox;
    private javax.swing.JTextField NameEdit;
    private javax.swing.JTextField NameEdit3;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JTextField PasswordTxtBox;
    private javax.swing.JTextField PasswordTxtBox3;
    private javax.swing.JButton RefreshButton;
    private javax.swing.JButton RefreshButton3;
    private javax.swing.JLabel Role;
    private javax.swing.JButton SaveHosp;
    private javax.swing.JTextField SearchBar;
    private javax.swing.JTextField SearchBar1;
    private javax.swing.JTextField SearchBar2;
    private javax.swing.JTextField SearchBar3;
    private javax.swing.JCheckBox ShoeCheckBox;
    private javax.swing.JComboBox<String> Sort;
    private javax.swing.JComboBox<String> Sort1;
    private javax.swing.JComboBox<String> Sort3;
    private javax.swing.JComboBox<String> Sort4;
    private javax.swing.JButton SupRefreshButton;
    private javax.swing.JButton SupRefreshButton1;
    private javax.swing.JTextField SuppNameEdit;
    private javax.swing.JTable SupplierDataTable;
    private javax.swing.JComboBox<String> UTsort;
    private javax.swing.JComboBox<String> UTsort3;
    private javax.swing.JTable UserDataTable;
    private javax.swing.JTable UserDataTable3;
    private javax.swing.JButton addButton;
    private javax.swing.JButton addButton3;
    private javax.swing.JRadioButton adminRadio;
    private javax.swing.JButton deleteButton;
    private javax.swing.JButton deleteButton1;
    private javax.swing.JButton deleteButton3;
    private javax.swing.JButton editButton;
    private javax.swing.JButton editButton1;
    private javax.swing.JButton editButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton staffRadio;
    private javax.swing.ButtonGroup usertypeChoose;
    // End of variables declaration//GEN-END:variables
}
